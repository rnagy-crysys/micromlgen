ARDUINO = 'arduino'
ATTINY = 'attiny'
ALL = [
    ARDUINO,
    ATTINY
]

ALLOWED_CLASSIFIERS = [
    'SVC',
    'OneClassSVM',
    'RVC',
    'SEFR',
    'DecisionTreeClassifier',
    'DecisionTreeRegressor',
    'RandomForestClassifier',
    'RandomForestRegressor',
    'GaussianNB',
    'LogisticRegression',
    'PCA',
    'PrincipalFFT',
    'LinearRegression',
    'XGBClassifier'
]